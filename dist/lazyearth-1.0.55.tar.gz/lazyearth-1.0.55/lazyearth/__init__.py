from lazyearth.common import objearth
from lazyearth.rsi import index
from lazyearth.virtual import *
from lazyearth.water import water
from lazyearth.cloud import *

__author__  = 'tul kedsaro'
__email__   = 'Tun.k@ku.th'
# # Test vrsion
# __version__ = '0.1.5'
# # Publish version
__version__ = '1.0.55'

print(f'Lazyearth version : {__version__} Krub')