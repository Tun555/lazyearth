# from lazyearth.mainfile import objearth

# # from configparser import ConfigParser

# # file = 'lazyearth.ini'
# # config = ConfigParser()
# # config.read(file)

# # fractionconstant = float(config['Plot']['fractionnumber'])
# # print(fractionconstant)

# # Nodata = int(config['Data']['Nodata'])
# # print(Nodata)

# # Cloud = (config['Cloud']['Fashcloud'])
# # print(Cloud)
